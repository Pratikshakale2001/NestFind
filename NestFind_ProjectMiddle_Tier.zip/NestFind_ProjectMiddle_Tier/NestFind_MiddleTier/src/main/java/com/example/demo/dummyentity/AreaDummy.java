package com.example.demo.dummyentity;

public class AreaDummy {
	
	int city_id;
	String area_name;
	int pin_code;
	
	
	public AreaDummy() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getCity_id() {
		return city_id;
	}


	public void setCity_id(int city_id) {
		this.city_id = city_id;
	}


	public String getArea_name() {
		return area_name;
	}


	public void setArea_name(String area_name) {
		this.area_name = area_name;
	}


	public int getPin_code() {
		return pin_code;
	}


	public void setPin_code(int pin_code) {
		this.pin_code = pin_code;
	}
	
	

}
