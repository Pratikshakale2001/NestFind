package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dummyentity.CityDummy;
import com.example.demo.entities.City;
import com.example.demo.entities.State;
import com.example.demo.services.CityServices;
import com.example.demo.services.StateServices;


@RestController
@RequestMapping("/api/cities")
public class CityController {
	
	
	@Autowired
	CityServices cityservices;
	
	@Autowired
	StateServices stateservice;
	
	@GetMapping
	public List<City>getAll(){
		return cityservices.getAllCity();
	}
	
	 @GetMapping("/{id}")
	    public City getCityById(@PathVariable int id) {
	        return cityservices.getById(id);
	    }
	
	@PostMapping
    public City saveCity(@RequestBody CityDummy cd) {
        int stateId = cd.getState_id();
        State state = stateservice.getById(stateId);

        City city = new City();
        city.setCity_name(cd.getCity_name());
        city.setState(state);

        return cityservices.savecity(city);
    }

}

