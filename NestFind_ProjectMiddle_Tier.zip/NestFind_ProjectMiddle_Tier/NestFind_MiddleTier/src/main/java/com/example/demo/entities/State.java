package com.example.demo.entities;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="state")
public class State {
	
	
	@Id
	int state_id;
	String state_name;
	
	
	//@JsonIgnoreProperties("state")
	@OneToMany(mappedBy = "state")
    @JsonManagedReference
    private Set<City> cities;
	
	

	public State() {
		super();
		// TODO Auto-generated constructor stub
	}



	public State(String state_name, Set<City> cities) {
		super();
		this.state_name = state_name;
		this.cities = cities;
	}



	public int getState_id() {
		return state_id;
	}



	public void setState_id(int state_id) {
		this.state_id = state_id;
	}



	public String getState_name() {
		return state_name;
	}



	public void setState_name(String state_name) {
		this.state_name = state_name;
	}



	public Set<City> getCities() {
		return cities;
	}



	public void setCities(Set<City> cities) {
		this.cities = cities;
	}

	
}
