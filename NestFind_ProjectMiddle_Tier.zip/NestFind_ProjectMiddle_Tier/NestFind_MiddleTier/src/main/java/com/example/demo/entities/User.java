/*package com.example.demo.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="user")
public class User {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int user_id;
	
	
	String f_name;
	String l_name;
	String email;
	String adhar_no;
	String pan_no;
	String mobile;
	String user_name;
	String password;
	
	
	
	//role and user	
	 @ManyToOne
	 @JsonBackReference
	 @JoinColumn(name="role_id")
	 Role role;
	
	
	//user and booking(1-1)
	 @OneToOne(mappedBy = "user")
	    @JsonBackReference("user-booking")
	    private Booking booking;
	
	
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}


	public User(String f_name, String l_name, String email, String adhar_no, String pan_no, String mobile,
			String user_name, String password, Role role, Booking booking) {
		super();
		this.f_name = f_name;
		this.l_name = l_name;
		this.email = email;
		this.adhar_no = adhar_no;
		this.pan_no = pan_no;
		this.mobile = mobile;
		this.user_name = user_name;
		this.password = password;
		this.role = role;
		this.booking = booking;
	}




	public Role getRole() {
		return role;
	}




	public void setRole(Role role) {
		this.role = role;
	}




	public int getUser_id() {
		return user_id;
	}




	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}




	public String getF_name() {
		return f_name;
	}




	public void setF_name(String f_name) {
		this.f_name = f_name;
	}




	public String getL_name() {
		return l_name;
	}




	public void setL_name(String l_name) {
		this.l_name = l_name;
	}




	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}




	public String getAdhar_no() {
		return adhar_no;
	}




	public void setAdhar_no(String adhar_no) {
		this.adhar_no = adhar_no;
	}




	public String getPan_no() {
		return pan_no;
	}




	public void setPan_no(String pan_no) {
		this.pan_no = pan_no;
	}




	public String getMobile() {
		return mobile;
	}




	public void setMobile(String mobile) {
		this.mobile = mobile;
	}




	public String getUser_name() {
		return user_name;
	}




	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}




	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}
	
	

	public Booking getBooking() {
		return booking;
	}





	public void setBooking(Booking booking) {
		this.booking = booking;
	}


	public User orElse(Object object) {
		// TODO Auto-generated method stub
		return null;
	}


	
	

}*/



/*package com.example.demo.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="user")
public class User {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int user_id;
	
	
	String f_name;
	String l_name;
	String email;
	String adhar_no;
	String pan_no;
	String mobile;
	String user_name;
	String password;
	
	
	
	//role and user	
	 @ManyToOne
	 @JsonBackReference
	 @JoinColumn(name="role_id")
	 Role role;
	
	

	
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}


	public User(String f_name, String l_name, String email, String adhar_no, String pan_no, String mobile,
			String user_name, String password, Role role) {
		super();
		this.f_name = f_name;
		this.l_name = l_name;
		this.email = email;
		this.adhar_no = adhar_no;
		this.pan_no = pan_no;
		this.mobile = mobile;
		this.user_name = user_name;
		this.password = password;
		this.role = role;
	
	}




	public Role getRole() {
		return role;
	}




	public void setRole(Role role) {
		this.role = role;
	}




	public int getUser_id() {
		return user_id;
	}




	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}




	public String getF_name() {
		return f_name;
	}




	public void setF_name(String f_name) {
		this.f_name = f_name;
	}




	public String getL_name() {
		return l_name;
	}




	public void setL_name(String l_name) {
		this.l_name = l_name;
	}




	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}




	public String getAdhar_no() {
		return adhar_no;
	}




	public void setAdhar_no(String adhar_no) {
		this.adhar_no = adhar_no;
	}




	public String getPan_no() {
		return pan_no;
	}




	public void setPan_no(String pan_no) {
		this.pan_no = pan_no;
	}




	public String getMobile() {
		return mobile;
	}




	public void setMobile(String mobile) {
		this.mobile = mobile;
	}




	public String getUser_name() {
		return user_name;
	}




	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}




	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}
	
	



	public User orElse(Object object) {
		// TODO Auto-generated method stub
		return null;
	}


	
	

}*/

package com.example.demo.entities;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="user")
public class User {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "user_id") 
	int id;	
	String f_name;
	String l_name;
	String email;
	String adhar_no;
	String pan_no;
	String mobile;
	String user_name;
	String password;
	
	
	
	//role and user	
	 @ManyToOne
	 @JsonManagedReference
	 @JoinColumn(name="role_id")
	 Role role;
	
	
	//user and booking(1-1)
	@OneToOne(mappedBy = "user")
	@JsonBackReference
	 Booking booking;
	
	@OneToMany(mappedBy = "user")
	@JsonManagedReference
    private Set<Property> properties;
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}


	public User(String f_name, String l_name, String email, String adhar_no, String pan_no, String mobile,
			String user_name, String password, Role role, Booking booking) {
		super();
		this.f_name = f_name;
		this.l_name = l_name;
		this.email = email;
		this.adhar_no = adhar_no;
		this.pan_no = pan_no;
		this.mobile = mobile;
		this.user_name = user_name;
		this.password = password;
		this.role = role;
		this.booking = booking;
	}










	public Role getRole() {
		return role;
	}




	public void setRole(Role role) {
		this.role = role;
	}

	


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getF_name() {
		return f_name;
	}




	public void setF_name(String f_name) {
		this.f_name = f_name;
	}




	public String getL_name() {
		return l_name;
	}




	public void setL_name(String l_name) {
		this.l_name = l_name;
	}




	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}




	public String getAdhar_no() {
		return adhar_no;
	}




	public void setAdhar_no(String adhar_no) {
		this.adhar_no = adhar_no;
	}




	public String getPan_no() {
		return pan_no;
	}




	public void setPan_no(String pan_no) {
		this.pan_no = pan_no;
	}




	public String getMobile() {
		return mobile;
	}




	public void setMobile(String mobile) {
		this.mobile = mobile;
	}




	public String getUser_name() {
		return user_name;
	}




	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}




	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}
	
	

	public Booking getBooking() {
		return booking;
	}





	public void setBooking(Booking booking) {
		this.booking = booking;
	}


	
	

}




