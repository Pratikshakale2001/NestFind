/*package com.example.demo.entities;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;


@Entity
@Table(name="payment")
public class Payment {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int pay_id;
	
	String pay_mode;
	Date pay_date; 
	double amount;
	
	//payment and booking(1-1)
	//@JsonIgnoreProperties("payment")
	 @OneToOne(mappedBy = "payment")
	 @JsonBackReference("payment-booking")
	 Booking booking;
	
	
	
	
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	




	public Payment(String pay_mode, Date pay_date, double amount, Booking booking) {
		super();
		this.pay_mode = pay_mode;
		this.pay_date = pay_date;
		this.amount = amount;
		this.booking = booking;
	}






	public int getPay_id() {
		return pay_id;
	}



	public void setPay_id(int pay_id) {
		this.pay_id = pay_id;
	}



	public String getPay_mode() {
		return pay_mode;
	}



	public void setPay_mode(String pay_mode) {
		this.pay_mode = pay_mode;
	}



	public Date getPay_date() {
		return pay_date;
	}



	public void setPay_date(Date pay_date) {
		this.pay_date = pay_date;
	}



	public double getAmount() {
		return amount;
	}



	public void setAmount(double amount) {
		this.amount = amount;
	}






	public Booking getBooking() {
		return booking;
	}






	public void setBooking(Booking booking) {
		this.booking = booking;
	}
	
	
	
	
	
	
}*/


package com.example.demo.entities;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;


@Entity
@Table(name="payment")
public class Payment {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int pay_id;
	
	String pay_mode;
	Date pay_date; 
	double amount;
	

	
	
	
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	




	public Payment(String pay_mode, Date pay_date, double amount) {
		super();
		this.pay_mode = pay_mode;
		this.pay_date = pay_date;
		this.amount = amount;
		
	}






	public int getPay_id() {
		return pay_id;
	}



	public void setPay_id(int pay_id) {
		this.pay_id = pay_id;
	}



	public String getPay_mode() {
		return pay_mode;
	}



	public void setPay_mode(String pay_mode) {
		this.pay_mode = pay_mode;
	}



	public Date getPay_date() {
		return pay_date;
	}



	public void setPay_date(Date pay_date) {
		this.pay_date = pay_date;
	}



	public double getAmount() {
		return amount;
	}



	public void setAmount(double amount) {
		this.amount = amount;
	}


	
	
}

