package com.example.demo.dummyentity;

public class LocationDummy {

	
		int property_id;
		int area_id;
		String address;
		
		
		
		public LocationDummy() {
			super();
			// TODO Auto-generated constructor stub
		}
		public int getProperty_id() {
			return property_id;
		}
		public void setProperty_id(int property_id) {
			this.property_id = property_id;
		}
		public int getArea_id() {
			return area_id;
		}
		public void setArea_id(int area_id) {
			this.area_id = area_id;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		
		
		
}

