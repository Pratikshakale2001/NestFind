package com.example.demo.services;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.UUID;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class PhotosServiceImpl implements PhotoService {

    private static final Logger logger = LoggerFactory.getLogger(PhotosServiceImpl.class);

    @Value("${image.upload.dir}")
    private String uploadDir;

    @Override
    public void savePhoto(String base64Image) {
        try {
            byte[] imageBytes = Base64.getDecoder().decode(base64Image);
            String fileName = UUID.randomUUID().toString() + ".png";
            Path filePath = Paths.get(uploadDir, fileName);
            Files.write(filePath, imageBytes);
        } catch (IOException e) {
            logger.error("Failed to save image", e);
            throw new RuntimeException("Failed to save image");
        }
    }
}
