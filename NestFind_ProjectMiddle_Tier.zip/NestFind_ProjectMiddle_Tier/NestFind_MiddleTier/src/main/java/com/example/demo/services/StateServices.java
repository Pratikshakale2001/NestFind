package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.State;
import com.example.demo.repositories.StateRepository;

@Service
public class StateServices {
	
	@Autowired
	StateRepository staterepo;
	
	
	
	public List<State>getAllState(){
		return staterepo.findAll();
	}
	
	
	   public State saveState(State state) {
	        return staterepo.save(state);
	    }
	   
	 //get by state id
	    public State getById(int stateId) {
	        Optional<State> stateOptional = staterepo.findById(stateId);
	        return stateOptional.orElse(null); // Return null if state not found
	    }
	
	    
	 // Update a state
	    public State updateState(int stateId, State stateDetails) {
	        State state = getById(stateId);
	        if (state != null) {
	            state.setState_name(stateDetails.getState_name());
	            state.setCities(stateDetails.getCities());
	            return staterepo.save(state);
	        }
	        return null;
	    }

	   


	    // Delete a state by ID
	    public boolean deleteState(int stateId) {
	        if (staterepo.existsById(stateId)) {
	            staterepo.deleteById(stateId);
	            return true;
	        }
	        return false;
	    }

}
