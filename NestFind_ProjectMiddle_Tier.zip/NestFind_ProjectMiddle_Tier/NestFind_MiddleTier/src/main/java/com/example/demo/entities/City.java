package com.example.demo.entities;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="city")
public class City {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int city_id;
	//int state_id;
	String city_name;
	
	
	
	@ManyToOne
    @JoinColumn(name = "state_id")
    @JsonBackReference
    private State state;
	

	
	 @OneToMany(mappedBy="city", cascade= CascadeType.ALL)
	 @JsonBackReference
     Set<Area>areas;
		
	 
	 
	public City() {
		super();
		// TODO Auto-generated constructor stub
	}




	
	public City(String city_name, State state, Set<Area> areas) {
		super();
		this.city_name = city_name;
		this.state = state;
		this.areas = areas;
	}







	public int getCity_id() {
		return city_id;
	}
	
	public void setCity_id(int city_id) {
		this.city_id = city_id;
	}


	public String getCity_name() {
		return city_name;
	}

	public void setCity_name(String city_name) {
		this.city_name = city_name;
	}
	
	
	 public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public Set<Area> getAreas() {
		return areas;
	}

	public void setAreas(Set<Area> areas) {
		this.areas = areas;
	}
	
	
	
	
}
