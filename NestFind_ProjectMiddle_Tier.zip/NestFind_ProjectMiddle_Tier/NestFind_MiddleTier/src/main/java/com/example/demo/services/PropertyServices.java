/*package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.City;
import com.example.demo.entities.Property;
import com.example.demo.repositories.PropertyRepository;

@Service
public class PropertyServices {

	@Autowired
	PropertyRepository prepo;
	
	public List<Property>getAllProperties(){
		return prepo.findAll();
	}
	
	
	public Property getPropertyById(int propertyid) {
		return prepo.findById(propertyid).get();
	}
	
	
	public Property saveProperty(Property property) {
		return prepo.save(property);
	}



}*/


package com.example.demo.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entities.Property;
import com.example.demo.repositories.PropertyRepository;
import com.example.demo.repositories.UserRepository;

@Service
public class PropertyServices {

	@Autowired
	PropertyRepository prepo;

	@Autowired
	UserRepository userRepository;

	public List<Property> getAllProperties() {
		return prepo.findAll();
	}

	public Property getById(int propertyid) {
		return prepo.findById(propertyid).get();
	}

	public Property saveProperty(Property property) {
		return prepo.save(property);
	}

	public List<Property> getPropertiesByUserId(int userId) {
		return prepo.findByUser_Id(userId);
	}

//	public Property updateProperty(int propertyId, Property propertyDetails) {
//		Property existingProperty = prepo.findById(propertyId)
//				.orElseThrow(() -> new RuntimeException("Property not found with id " + propertyId));
//
//		existingProperty.setProperty_type_id(propertyDetails.getProperty_type_id());
//		existingProperty.setUser(propertyDetails.getUser());
//		existingProperty.setRent_price(propertyDetails.getRent_price());
//		existingProperty.setDeposit(propertyDetails.getDeposit());
//		existingProperty.setAddress(propertyDetails.getAddress());
//		existingProperty.setLocation(propertyDetails.getLocation());
//		return prepo.save(existingProperty);
//	}

}
