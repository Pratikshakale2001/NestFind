package com.example.demo.dummyentity;

public class AmenitiesDummy {
	
	String amenities_name;
	
	

	public AmenitiesDummy() {
		super();
		// TODO Auto-generated constructor stub
	}



	public String getAmenities_name() {
		return amenities_name;
	}



	public void setAmenities_name(String amenities_name) {
		this.amenities_name = amenities_name;
	}
	
	

}
