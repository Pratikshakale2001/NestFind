package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.City;
import com.example.demo.entities.Property_Type;
import com.example.demo.services.PropertyTypeServices;



@RestController
@RequestMapping("/api/propertytype")
public class PropertyTypeController {

	
	@Autowired
	PropertyTypeServices ptservices;
	
	@GetMapping
	public List<Property_Type>getAll(){
		return ptservices.getAllPropertyType();
	}
	
	
	@GetMapping("/{id}")
    public Property_Type getPropertyTypeById(@PathVariable int id) {
        return ptservices.getById(id);
    }
	
	
}
