/*package com.example.demo.entities;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="property")

public class Property {
	
	
@Id	
@GeneratedValue(strategy=GenerationType.IDENTITY)
 int property_id;


 
// int fk_user_id;
 double rent_price;
 double deposit;
 int property_type_id;
 
 //property & User
 /*@ManyToOne
 @JsonBackReference
 @JoinColumn(name="user_id")
 User user;
  
 

 
 
 
//int property_type_id;
int user_id;
 

/*@ManyToOne
@JsonManagedReference
@JoinColumn(name="property_type_id")
Property_Type property_type;




//location and property
@OneToOne(mappedBy="property", cascade=CascadeType.ALL)
@JsonManagedReference
Location location;

 
 
 //property and property_amenities (1-m)
 @OneToMany(mappedBy="property", cascade= CascadeType.ALL)
 @JsonManagedReference
 Set<Property_Amenities>property_amenities;
 
 
 
 
 
//property and photos (1-m)

@OneToMany(mappedBy="property", cascade= CascadeType.ALL)
@JsonManagedReference
Set<Photos>photos;
 

//property and booking

@OneToOne(mappedBy = "property")
@JsonManagedReference("property-booking")
private Booking booking;



 
public Property() {
	super();
	// TODO Auto-generated constructor stub
}







/*
 * public Property(double rent_price, double deposit, int property_type_id, int
 * user_id, Location location, Set<Property_Amenities> property_amenities,
 * Set<Photos> photos, Booking booking) { super(); this.rent_price = rent_price;
 * this.deposit = deposit; this.property_type_id = property_type_id;
 * this.user_id = user_id; this.location = location; this.property_amenities =
 * property_amenities; this.photos = photos; this.booking = booking; }
 




public int getProperty_id() {
	return property_id;
}

public Property(double rent_price, double deposit,int property_type_id, int user_id, Location location,
		Set<Photos> photos, Booking booking) {
	super();
	this.rent_price = rent_price;
	this.deposit = deposit;
	this.property_type_id = property_type_id;
	this.user_id = user_id;
	this.location = location;
	this.photos = photos;
	this.booking = booking;
}







public void setProperty_id(int property_id) {
	this.property_id = property_id;
}


public double getRent_price() {
	return rent_price;
}

public void setRent_price(double rent_price) {
	this.rent_price = rent_price;
}

public double getDeposit() {
	return deposit;
}

public void setDeposit(double deposit) {
	this.deposit = deposit;
}


public int getUser_id() {
	return user_id;
}


public void setUser_id(int user_id) {
	this.user_id = user_id;
}




public Location getLocation() {
	return location;
}


public void setLocation(Location location) {
	this.location = location;
}


/*
 * public Set<Property_Amenities> getProperty_amenities() { return
 * property_amenities; }
 





  public int getProperty_type_id() { return property_type_id; }
  
  
  
  
  public void setProperty_type_id(int property_type_id) { this.property_type_id
  = property_type_id; }
 



/*
 * public void setProperty_amenities(Set<Property_Amenities> property_amenities)
 * { this.property_amenities = property_amenities; }
 



public Set<Photos> getPhotos() {
	return photos;
}




public void setPhotos(Set<Photos> photos) {
	this.photos = photos;
}




public Booking getBooking() {
	return booking;
}




public void setBooking(Booking booking) {
	this.booking = booking;
}







/*public Property_Type getPropertytype() {
	return property_type;
}







public void setPropertytype(Property_Type propertytype) {
	this.property_type = propertytype;
}







public Set<Property_Amenities> getProperty_amenities() {
	return property_amenities;
}







public void setProperty_amenities(Set<Property_Amenities> property_amenities) {
	this.property_amenities = property_amenities;
}







public Property orElse(Object object) {
	// TODO Auto-generated method stub
	return null;
}
 
 
 
 
 

}*/


/*
package com.example.demo.entities;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="property")

public class Property {
	
	
@Id	
@GeneratedValue(strategy=GenerationType.IDENTITY)
 int property_id;


 
// int fk_user_id;
 double rent_price;
 double deposit;
 int property_type_id;
 


 
 
 

int user_id;
 




//location and property
@OneToOne(mappedBy="property", cascade=CascadeType.ALL)
@JsonManagedReference
Location location;

 
 
 //property and property_amenities (1-m)
 @OneToMany(mappedBy="property", cascade= CascadeType.ALL)
 @JsonManagedReference
 Set<Property_Amenities>property_amenities;
 
 
 
 
 
//property and photos (1-m)

@OneToMany(mappedBy="property", cascade= CascadeType.ALL)
@JsonManagedReference
Set<Photos>photos;
 



 
public Property() {
	super();
	// TODO Auto-generated constructor stub
}







/*
 * public Property(double rent_price, double deposit, int property_type_id, int
 * user_id, Location location, Set<Property_Amenities> property_amenities,
 * Set<Photos> photos, Booking booking) { super(); this.rent_price = rent_price;
 * this.deposit = deposit; this.property_type_id = property_type_id;
 * this.user_id = user_id; this.location = location; this.property_amenities =
 * property_amenities; this.photos = photos; this.booking = booking; }
 




public int getProperty_id() {
	return property_id;
}

public Property(double rent_price, double deposit,int property_type_id, int user_id, Location location,
		Set<Photos> photos) {
	super();
	this.rent_price = rent_price;
	this.deposit = deposit;
	this.property_type_id = property_type_id;
	this.user_id = user_id;
	this.location = location;
	this.photos = photos;

}







public void setProperty_id(int property_id) {
	this.property_id = property_id;
}


public double getRent_price() {
	return rent_price;
}

public void setRent_price(double rent_price) {
	this.rent_price = rent_price;
}

public double getDeposit() {
	return deposit;
}

public void setDeposit(double deposit) {
	this.deposit = deposit;
}


public int getUser_id() {
	return user_id;
}


public void setUser_id(int user_id) {
	this.user_id = user_id;
}




public Location getLocation() {
	return location;
}


public void setLocation(Location location) {
	this.location = location;
}


/*
 * public Set<Property_Amenities> getProperty_amenities() { return
 * property_amenities; }
 





  public int getProperty_type_id() { return property_type_id; }
  
  
  
  
  public void setProperty_type_id(int property_type_id) { this.property_type_id
  = property_type_id; }
 



/*
 * public void setProperty_amenities(Set<Property_Amenities> property_amenities)
 * { this.property_amenities = property_amenities; }
 



public Set<Photos> getPhotos() {
	return photos;
}




public void setPhotos(Set<Photos> photos) {
	this.photos = photos;
}











/*public Property_Type getPropertytype() {
	return property_type;
}







public void setPropertytype(Property_Type propertytype) {
	this.property_type = propertytype;
}







public Set<Property_Amenities> getProperty_amenities() {
	return property_amenities;
}







public void setProperty_amenities(Set<Property_Amenities> property_amenities) {
	this.property_amenities = property_amenities;
}







public Property orElse(Object object) {
	// TODO Auto-generated method stub
	return null;
}
 
 
 
 
 

}*/

package com.example.demo.entities;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name = "property")
public class Property {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int property_id;

	private double rent_price;
	private double deposit;
	private int property_type_id;
//	private int user_id;
	private String address;

	/*
	 * // Property and Location (1-1)
	 * 
	 * @OneToOne(mappedBy = "property", cascade = CascadeType.ALL)
	 * 
	 * @JsonManagedReference private Location location;
	 */

	@OneToOne(cascade = CascadeType.ALL)
	@JsonManagedReference
	@JoinColumn(name = "location_id")
	private Location location;

	// Property and Property_Amenities (1-m)
	@OneToMany(mappedBy = "property", cascade = CascadeType.ALL)
	@JsonManagedReference
	private Set<Property_Amenities> property_amenities;

	// Property and Photos (1-m)
	@OneToMany(mappedBy = "property", cascade = CascadeType.ALL)
	@JsonManagedReference
	private Set<Photos> photos;

	// Property and Booking (1-1)
	@OneToOne(mappedBy = "property", cascade = CascadeType.ALL)
	@JsonManagedReference
	private Booking booking;

	@ManyToOne
	@JsonBackReference
	@JoinColumn(name = "user_id")
	private User user;

	public Property() {
		super();
	}

	public Property(double rent_price, String address, double deposit, int property_type_id, Location location,
			Set<Photos> photos, Booking booking) {
		this.rent_price = rent_price;
		this.deposit = deposit;
		this.property_type_id = property_type_id;
//		this.user_id = user_id;
		this.location = location;
		this.photos = photos;
		this.booking = booking;
		this.address = address;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getProperty_id() {
		return property_id;
	}

	public void setProperty_id(int property_id) {
		this.property_id = property_id;
	}

	public double getRent_price() {
		return rent_price;
	}

	public void setRent_price(double rent_price) {
		this.rent_price = rent_price;
	}

	public double getDeposit() {
		return deposit;
	}

	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}

	public int getProperty_type_id() {
		return property_type_id;
	}

	public void setProperty_type_id(int property_type_id) {
		this.property_type_id = property_type_id;
	}

//	public int getUser_id() {
//		return user_id;
//	}
//
//	public void setUser_id(int user_id) {
//		this.user_id = user_id;
//	}

	public Location getLocation() {
		return location;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public Set<Property_Amenities> getProperty_amenities() {
		return property_amenities;
	}

	public void setProperty_amenities(Set<Property_Amenities> property_amenities) {
		this.property_amenities = property_amenities;
	}

	public Set<Photos> getPhotos() {
		return photos;
	}

	public void setPhotos(Set<Photos> photos) {
		this.photos = photos;
	}

	public Booking getBooking() {
		return booking;
	}

	public void setBooking(Booking booking) {
		this.booking = booking;
	}
}

