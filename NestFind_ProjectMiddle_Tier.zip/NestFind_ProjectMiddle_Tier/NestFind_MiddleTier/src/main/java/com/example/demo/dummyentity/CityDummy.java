package com.example.demo.dummyentity;

public class CityDummy {
	
	int state_id;
	String city_name;
	
	
	
	public CityDummy() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getState_id() {
		return state_id;
	}


	public void setState_id(int state_id) {
		this.state_id = state_id;
	}


	public String getCity_name() {
		return city_name;
	}


	public void setCity_name(String city_name) {
		this.city_name = city_name;
	}
	
	
	
	

}
