package com.example.demo.dummyentity;

public class UserPropertyDummy {
	private String f_name;
	private String l_name;
	private String email;
	private String mobile;
	private int propertyTypeId;
	private double rentPrice;
	private double deposit;
	private String address;
//	private String property_type_name;

	

	public UserPropertyDummy(String f_name, String l_name, String email, String mobile, int propertyTypeId,
			double rentPrice, double deposit, String address) {
		super();
		this.f_name = f_name;
		this.l_name = l_name;
		this.email = email;
		this.mobile = mobile;
		this.propertyTypeId = propertyTypeId;
		this.rentPrice = rentPrice;
		this.deposit = deposit;
		this.address = address;
//		this.property_type_name = property_type_name;
	}

	public String getF_name() {
		return f_name;
	}

	public void setF_name(String f_name) {
		this.f_name = f_name;
	}

	public String getL_name() {
		return l_name;
	}

	public void setL_name(String l_name) {
		this.l_name = l_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public int getPropertyTypeId() {
		return propertyTypeId;
	}

	public void setPropertyTypeId(int propertyTypeId) {
		this.propertyTypeId = propertyTypeId;
	}

	public double getRentPrice() {
		return rentPrice;
	}

	public void setRentPrice(double rentPrice) {
		this.rentPrice = rentPrice;
	}

	public double getDeposit() {
		return deposit;
	}

	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

//	public String getProperty_type_name() {
//		return property_type_name;
//	}
//
//	public void setProperty_type_name(String property_type_name) {
//		this.property_type_name = property_type_name;
//	}

}