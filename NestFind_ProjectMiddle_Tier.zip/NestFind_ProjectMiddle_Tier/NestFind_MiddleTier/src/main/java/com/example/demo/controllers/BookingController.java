package com.example.demo.controllers;

import com.example.demo.entities.Booking;
import com.example.demo.entities.State;
import com.example.demo.services.BookingServices;
import com.example.demo.dummyentity.BookingDummy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {

  /*  @Autowired
    BookingServices bookingService;

    // Create a new booking
    @PostMapping
    public ResponseEntity<Booking> createBooking(@RequestBody BookingDummy bookingDummy) {
        Booking booking = new Booking(
            booking.setbookingDummy.getB_date(),
            bookingDummy.getStart_date(),
            bookingDummy.getEnd_date(),
            bookingDummy.getRent_price(),
            bookingDummy.getDeposit(),
            bookingDummy.getProperty_id(),
            bookingDummy.getUser_id(),
            bookingDummy.getPay_id()
        );
        Booking savedBooking = bookingService.save(booking);
        return new ResponseEntity<>(savedBooking, HttpStatus.CREATED);
        
        
        /* State state = new State();
        state.setState_id(sd.getState_id());
        state.setState_name(sd.getState_name());
       
        return stateservice.saveState(state);*
        
        
    }

    // Get all bookings
    @GetMapping
    public ResponseEntity<List<Booking>> getAllBookings() {
        List<Booking> bookings = bookingService.findAll();
        return new ResponseEntity<>(bookings, HttpStatus.OK);
    }

    // Get booking by ID
    @GetMapping("/{id}")
    public ResponseEntity<Booking> getBookingById(@PathVariable int id) {
        Booking booking = bookingService.findById(id);
        if (booking != null) {
            return new ResponseEntity<>(booking, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Update a booking
    @PutMapping("/{id}")
    public ResponseEntity<Booking> updateBooking(
            @PathVariable int id, @RequestBody BookingDummy bookingDummy) {
        Booking existingBooking = bookingService.findById(id);
        if (existingBooking != null) {
            existingBooking.setB_date(bookingDummy.getB_date());
            existingBooking.setStart_date(bookingDummy.getStart_date());
            existingBooking.setEnd_date(bookingDummy.getEnd_date());
            existingBooking.setRent_price(bookingDummy.getRent_price());
            existingBooking.setDeposit(bookingDummy.getDeposit());
            existingBooking.setProperty_id(bookingDummy.getProperty_id());
            existingBooking.setUser_id(bookingDummy.getUser_id());
            existingBooking.setPay_id(bookingDummy.getPay_id());
            Booking updatedBooking = bookingService.save(existingBooking);
            return new ResponseEntity<>(updatedBooking, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Delete a booking
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBooking(@PathVariable int id) {
        if (bookingService.existsById(id)) {
            bookingService.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }*/
}
