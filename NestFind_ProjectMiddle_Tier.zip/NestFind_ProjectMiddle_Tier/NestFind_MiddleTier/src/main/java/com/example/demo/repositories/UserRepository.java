package com.example.demo.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.example.demo.dummyentity.UserPropertyDummy;
import com.example.demo.entities.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

	@Query("SELECT new com.example.demo.dummyentity.UserPropertyDummy(u.f_name, u.l_name, u.email, u.mobile, p.property_type_id, p.rent_price, p.deposit, p.address) "
			+ "FROM User u JOIN u.properties p WHERE u.role.role_name = :roleName")
	List<UserPropertyDummy> findUserPropertiesByRole(@Param("roleName") String roleName);

}