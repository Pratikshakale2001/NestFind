package com.example.demo.dummyentity;

import java.util.List;

public class PropertyAmenitiesDummy {
    
    private int property_id;
    private List<Integer> amenities_ids;

    public PropertyAmenitiesDummy() {
        super();
    }

    public int getProperty_id() {
        return property_id;
    }

    public void setProperty_id(int property_id) {
        this.property_id = property_id;
    }

    public List<Integer> getAmenities_ids() {
        return amenities_ids;
    }

    public void setAmenities_ids(List<Integer> amenities_ids) {
        this.amenities_ids = amenities_ids;
    }
}
