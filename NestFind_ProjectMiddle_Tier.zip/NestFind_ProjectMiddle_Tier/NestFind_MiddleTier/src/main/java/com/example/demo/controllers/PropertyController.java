/*package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dummyentity.PropertyDummy;
import com.example.demo.entities.City;
import com.example.demo.entities.Property;
import com.example.demo.entities.Property_Type;
import com.example.demo.services.PropertyServices;
import com.example.demo.services.PropertyTypeServices;
import com.example.demo.services.UserServices;

@RestController
@RequestMapping("/api/properties")
public class PropertyController {
	
	@Autowired
	PropertyServices pservice;
	
	@Autowired
	PropertyTypeServices ptservice;
	
	
	@GetMapping
	public List<Property>getAll(){
		return pservice.getAllProperties();
	}
	
	
	@PostMapping
	public Property saveProperty(@RequestBody PropertyDummy pd) {
		
		
		Property property = new Property();
		property.setRent_price(pd.getRent_price());
		property.setDeposit(pd.getDeposit());
	
		property.setUser_id(pd.getUser_id());
		
		/*int propertytypeId = pd.getProperty_type_id();
		Property_Type pttype = ptservice.getById(pttype);

			
		return pservice.saveProperty(property);}
		
		   @GetMapping("/search")
		    public ResponseEntity<List<Property>> searchProperties(
		            @RequestParam(required = false) Integer stateId,
		            @RequestParam(required = false) Integer cityId,
		            @RequestParam(required = false) Integer areaId,
		            @RequestParam(required = false) Integer propertyTypeId) {

		        try {
		            List<Property> properties = pservice.searchProperties(stateId, cityId, areaId, propertyTypeId);
		            return ResponseEntity.ok(properties);
		        } catch (Exception e) {
		            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
		        }
		
	}*/

/*package com.example.demo.controllers;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dummyentity.PropertyDummy;
import com.example.demo.entities.Amenities;
import com.example.demo.entities.Area;
import com.example.demo.entities.Location;
import com.example.demo.entities.Property;
import com.example.demo.entities.Property_Amenities;
import com.example.demo.entities.Property_Type;
import com.example.demo.entities.State;
import com.example.demo.repositories.AmenitiesRepository;
import com.example.demo.repositories.LocationRepository;
import com.example.demo.services.PropertyServices;
import com.example.demo.services.PropertyTypeServices;
import com.example.demo.services.UserServices;

@RestController
@RequestMapping("/api/properties")
public class PropertyController {
	
	@Autowired
	PropertyServices pservice;
	
	@Autowired
	PropertyTypeServices ptservice;
	
	@Autowired
	AmenitiesRepository amenityRepository;
	
	@Autowired
	LocationRepository locr;
	
	
	@GetMapping
	public List<Property>getAll(){
		return pservice.getAllProperties();
	}
	
	
	@GetMapping("/{id}")
    public Property getPropertyById(@PathVariable("id") int id) {
        return pservice.getPropertyById(id);
    }
	
	
	@PostMapping
    public Property saveProperty(@RequestBody PropertyDummy pd) {
        Property property = new Property();

        property.setRent_price(pd.getRent_price());
        property.setDeposit(pd.getDeposit());
        property.setProperty_type_id(pd.getProperty_type_id());;
        property.setUser_id(pd.getUser_id());

        // Fetch location details and set to property
        Optional<Location> loc = locr.findById(pd.getArea_id());
        if (loc.isPresent()) {
            property.setLocation(loc.get());
        }

        // Handling amenities
        Set<Property_Amenities> propertyAmenitiesSet = new HashSet<>();
        for (Integer amenityId : pd.getAmenities_ids()) {
            Optional<Amenities> amenityOpt = amenityRepository.findById(amenityId);
            if (amenityOpt.isPresent()) {
                Amenities amenity = amenityOpt.get();
                
                Property_Amenities propertyAmenity = new Property_Amenities();
                Set<Amenities> amenitySet = new HashSet<>();
                amenitySet.add(amenity);
                propertyAmenity.setAmenities(amenitySet);
                propertyAmenity.setProperty(property);
                propertyAmenitiesSet.add(propertyAmenity);
            }
        }
        property.setProperty_amenities(propertyAmenitiesSet);

        try {
            return pservice.saveProperty(property);
        } catch (DataIntegrityViolationException e) {
            System.err.println("Data Integrity Violation: " + e.getMessage());
            throw e;
        } catch (Exception e) {
            System.err.println("Error saving property: " + e.getMessage());
            throw e;
        }
    }
	
	
	

}*/

package com.example.demo.controllers;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dummyentity.PropertyDummy;
import com.example.demo.entities.Amenities;
import com.example.demo.entities.Location;
import com.example.demo.entities.Property;
import com.example.demo.entities.Property_Amenities;
import com.example.demo.entities.User;
import com.example.demo.repositories.AmenitiesRepository;
import com.example.demo.repositories.LocationRepository;
import com.example.demo.repositories.PropertyRepository;
import com.example.demo.repositories.UserRepository;
import com.example.demo.services.PropertyServices;

@RestController
@RequestMapping("/api/properties")
public class PropertyController {

	@Autowired
	private AmenitiesRepository amenityRepository;

	@Autowired
	private LocationRepository locr;

	@Autowired
	private PropertyServices pservice;

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	PropertyRepository propertyRepository;

	@GetMapping
	public List<Property> getAll() {
		return pservice.getAllProperties();
	}

	@GetMapping("/{userId}")
	public ResponseEntity<List<Property>> getPropertiesByUserId(@PathVariable int userId) {
		List<Property> properties = pservice.getPropertiesByUserId(userId);
		return ResponseEntity.ok(properties);
	}

	
//	 @PutMapping("/{propertyId}")
//	    public ResponseEntity<Property> updateProperty(
//	            @PathVariable int propertyId,
//	            @RequestBody Property propertyDetails) {
//	        Property updatedProperty = pservice.updateProperty(propertyId, propertyDetails);
//	        return new ResponseEntity<>(updatedProperty, HttpStatus.OK);
//	    }


	@PostMapping
	public Property saveProperty(@RequestBody PropertyDummy pd) {
		Property property = new Property();
		property.setRent_price(pd.getRent_price());
		property.setDeposit(pd.getDeposit());
		property.setProperty_type_id(pd.getProperty_type_id());
		// Fetch and set the User
		Optional<User> userOpt = userRepository.findById(pd.getUser_id());
		if (userOpt.isPresent()) {
			property.setUser(userOpt.get());
		} else {
			throw new RuntimeException("User not found with ID: " + pd.getUser_id());
		}
		property.setAddress(pd.getAddress());
		Optional<Location> loc = locr.findById(pd.getArea_id());
		if (loc.isPresent()) {
			property.setLocation(loc.get());
		}

		// Handling amenities
		Set<Property_Amenities> propertyAmenitiesSet = new HashSet<>();
		for (Integer amenityId : pd.getAmenities_ids()) {
			Optional<Amenities> amenityOpt = amenityRepository.findById(amenityId);
			if (amenityOpt.isPresent()) {
				Amenities amenity = amenityOpt.get();
				Property_Amenities propertyAmenity = new Property_Amenities();
				Set<Amenities> amenitySet = new HashSet<>();
				amenitySet.add(amenity);
				propertyAmenity.setAmenities(amenitySet);
				propertyAmenity.setProperty(property);
				propertyAmenitiesSet.add(propertyAmenity);
			}
		}
		property.setProperty_amenities(propertyAmenitiesSet);

		try {
			return pservice.saveProperty(property);
		} catch (DataIntegrityViolationException e) {
			System.err.println("Data Integrity Violation: " + e.getMessage());
			throw e;
		} catch (Exception e) {
			System.err.println("Error saving property: " + e.getMessage());
			throw e;
		}
	}
}








