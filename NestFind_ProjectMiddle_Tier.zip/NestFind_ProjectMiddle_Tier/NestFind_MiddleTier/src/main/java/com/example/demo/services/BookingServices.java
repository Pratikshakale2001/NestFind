package com.example.demo.services;

import com.example.demo.entities.Booking;
import java.util.List;

public interface BookingServices {
    Booking save(Booking booking);
    List<Booking> findAll();
    Booking findById(int id);
    void deleteById(int id);
    boolean existsById(int id);
}