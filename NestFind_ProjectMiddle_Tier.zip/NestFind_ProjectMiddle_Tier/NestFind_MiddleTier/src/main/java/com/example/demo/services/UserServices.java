/*package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.User;
import com.example.demo.repositories.UserRepository;

@Service
public class UserServices {
	

		@Autowired
		UserRepository user_repo;
		
		
		public List<User>getAllUsers(){
			return user_repo.findAll();
		}
		
		
		public User getById(int userid) {
			return user_repo.findById(userid).get();
		}
		
		public User saveUser(User user) {
			return user_repo.save(user);
		}

}*/

package com.example.demo.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dummyentity.UserPropertyDummy;
import com.example.demo.entities.User;
import com.example.demo.repositories.PropertyRepository;
import com.example.demo.repositories.UserRepository;

@Service
public class UserServices {

	@Autowired
	UserRepository user_repo;

	@Autowired
	PropertyRepository prepo;

	public List<User> getAllUsers() {
		return user_repo.findAll();
	}

	public User getById(int user_id) {
		return user_repo.findById(user_id).get();
	}

	public User saveUser(User user) {
		return user_repo.save(user);
	}

	public List<UserPropertyDummy> getUsersByRole(String roleName) {
		return user_repo.findUserPropertiesByRole(roleName);
	}

}
