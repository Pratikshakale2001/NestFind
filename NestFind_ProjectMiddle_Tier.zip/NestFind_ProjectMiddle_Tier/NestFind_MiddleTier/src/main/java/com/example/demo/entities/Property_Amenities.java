package com.example.demo.entities;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="property_amenities")
public class Property_Amenities {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    int property_amenities_id;
     
//int amenities_id;


	
	
      
	 // property_amenities and property (m-1)
	 //@JsonIgnoreProperties("property_amenities")
	 @ManyToOne
	 @JsonBackReference
	 @JoinColumn(name="property_id")
	 Property property;
	
	
	  // @JsonIgnoreProperties("property_amenities")
	   @ManyToMany(cascade = CascadeType.ALL)
	   @JsonManagedReference
	   @JoinTable(
		name = "property_amenities_amenities",
	    joinColumns = @JoinColumn(name = "property_amenities_id"),
	    inverseJoinColumns = @JoinColumn(name = "amenities_id")
	    )
	    Set<Amenities> amenities;
	 
	 
	 
	
public Property_Amenities() {
	super();
	// TODO Auto-generated constructor stub
}





public Property_Amenities(Property property, Set<Amenities> amenities) {
	super();
	this.property = property;
	this.amenities = amenities;
}












public Property_Amenities(int property_amenities_id) {
	super();
	this.property_amenities_id = property_amenities_id;
}









public Property_Amenities(Property property) {
	super();
	this.property = property;
}





public int getProperty_amenities_id() {
	return property_amenities_id;
}


public void setProperty_amenities_id(int property_amenities_id) {
	this.property_amenities_id = property_amenities_id;
}





public Property getProperty() {
	return property;
}





public void setProperty(Property property) {
	this.property = property;
}





public Set<Amenities> getAmenities() {
	return amenities;
}











public void setAmenities(Set<Amenities> amenities) {
	this.amenities = amenities;
}




	
	
}
