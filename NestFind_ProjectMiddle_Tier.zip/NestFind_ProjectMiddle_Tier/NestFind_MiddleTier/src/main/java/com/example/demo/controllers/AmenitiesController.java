package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dummyentity.AmenitiesDummy;
import com.example.demo.dummyentity.AreaDummy;
import com.example.demo.entities.Amenities;
import com.example.demo.entities.Area;
import com.example.demo.entities.City;
import com.example.demo.services.AmenitiesServices;

@RestController
@RequestMapping("/api/amenities")
public class AmenitiesController {
	
	@Autowired
	AmenitiesServices aservice;
	
	@GetMapping
	public List<Amenities> getAll(){
		return aservice.getAllAmenities();
	}
	
	
	
	
	@PostMapping
	 public Amenities saveAmenities(@RequestBody AmenitiesDummy am) {
	        Amenities amenities = new Amenities();
	        amenities.setAmenities_name(am.getAmenities_name());
	        return aservice.saveamenities(amenities);
	    }
	
	


}
