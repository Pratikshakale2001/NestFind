package com.example.demo.services;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Photos;
import com.example.demo.repositories.PhotosRepository;

@Service
public class PhotosServices {

	@Autowired
	PhotosRepository phrepo;
	
	public List<Photos>getAllPhotos(){
		return phrepo.findAll();
	}
	
	
	@Value("${image.upload.dir}")
    private String uploadDir;

    public void saveImage(String base64Image) {
        try {
            byte[] imageBytes = Base64.getDecoder().decode(base64Image);
            String fileName = UUID.randomUUID().toString() + ".png"; // or another format
            Path filePath = Paths.get(uploadDir, fileName);
            Files.write(filePath, imageBytes);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to save image");
        }
    }
	
}
