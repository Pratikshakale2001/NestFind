package com.example.demo.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "photos")
public class Photos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int photoId; // Renamed for consistency with Java naming conventions

    @Lob
    @Column(columnDefinition = "LONGBLOB")
    private byte[] images;

    @ManyToOne
    @JsonBackReference
    @JoinColumn(name = "property_id")
    private Property property;

    // Default constructor
    public Photos() {
    }

    // Parameterized constructor
    public Photos(byte[] images, Property property) {
        this.images = images;
        this.property = property;
    }

    // Getters and setters
    public int getPhotoId() {
        return photoId;
    }

    public void setPhotoId(int photoId) {
        this.photoId = photoId;
    }

    public byte[] getImages() {
        return images;
    }

    public void setImages(byte[] images) {
        this.images = images;
    }

    public Property getProperty() {
        return property;
    }

    public void setProperty(Property property) {
        this.property = property;
    }
}
