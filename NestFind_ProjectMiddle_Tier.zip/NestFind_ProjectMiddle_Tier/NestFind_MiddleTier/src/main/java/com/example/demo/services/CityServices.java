package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.City;
import com.example.demo.entities.State;
import com.example.demo.repositories.CityRepository;


@Service
public class CityServices {
	
	@Autowired
	CityRepository cityrepo;
	
	public List<City>getAllCity(){
		return cityrepo.findAll();
	}
	
	
	
	public City getById(int cityid) {
		return cityrepo.findById(cityid).get();
	}

	
	/* public City getById(int cityId) {
	        Optional<City> city = cityrepo.findById(cityId);
	        return city.orElse(null);
	    }*/
	
	
	
	public City savecity(City city) {
		return cityrepo.save(city);
	}
	
	//updatecity by id
			public City updateCity(int id, String city_name, State state) {
		        Optional<City> cityOptional = cityrepo.findById(id);
		        if (cityOptional.isPresent()) {
		            City city = cityOptional.get();
		            city.setCity_name(city_name);
		            city.setState(state);
		            return cityrepo.save(city);
		        }
		        return null;
		    }
			
		/*	//delete city by id
			 public void deleteCity(int id) {
			        cityrepo.deleteById(id);
			    }*/
}
