/*package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.User;
import com.example.demo.services.UserServices;



	@RestController
	@RequestMapping("/api/users")
	public class UserController {
		
		@Autowired
		UserServices userservice;
		
		/*
		 * @Autowired CityServices cityservice;
		 
		
		@GetMapping
		public List<User> getAll(){
			return userservice.getAllUsers();
		}
		
		/*@PostMapping
		public Area saveArea(@RequestBody AreaDummy ad) {
			int cityId = ad.getCity_id();
			City city = cityservice.getById(cityId);
			
			Area area = new Area();
			area.setArea_name(ad.getArea_name());
			area.setPin_code(ad.getPin_code());
			area.setCity(city);
			
			return areaservice.savearea(area);
			
		}*
}*/

package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dummyentity.UserPropertyDummy;
import com.example.demo.entities.User;
import com.example.demo.services.UserServices;


//@CrossOrigin(origins= {"http://localhost:3000","http://localhost:3001"})
	@RestController
	@RequestMapping("/api/users")
	public class UserController {
		
		@Autowired
		UserServices userservice;
		
		/*
		 * @Autowired CityServices cityservice;
		 */
		/*
		 * @GetMapping public List<User> getAll(){ return userservice.getAllUsers(); }
		 */
		
		/*@PostMapping
		public Area saveArea(@RequestBody AreaDummy ad) {
			int cityId = ad.getCity_id();
			City city = cityservice.getById(cityId);
			
			Area area = new Area();
			area.setArea_name(ad.getArea_name());
			area.setPin_code(ad.getPin_code());
			area.setCity(city);
			
			return areaservice.savearea(area);
			
		}*/
		
		@GetMapping("/by-role")
	    public List<UserPropertyDummy>getUsersByRole(@RequestParam String roleName) {
	        return userservice.getUsersByRole(roleName);
	    }
		
}
