package com.example.demo.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="location")
public class Location {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int location_id;
	//int property_id;
	//int area_id;
	
	
	
	 @ManyToOne
	 @JsonManagedReference
	 @JoinColumn(name="area_id")
	 Area area;
	

	 @OneToOne
	 @JsonBackReference
	 @JoinColumn(name="property_id")
	 Property property;
	
	
	public Location() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	




	public Location( Area area, Property property) {
		super();
	
		this.area = area;
		this.property = property;
	}






	public int getLocation_id() {
		return location_id;
	}
	
	public Area getArea() {
		return area;
	}



	public void setArea(Area area) {
		this.area = area;
	}



	public Property getProperty() {
		return property;
	}



	public void setProperty(Property property) {
		this.property = property;
	}



	public void setLocation_id(int location_id) {
		this.location_id = location_id;
	}

	

	
	

	
	
	
	
}
