package com.example.demo.services;

public interface PhotoService {
    void savePhoto(String base64Image);
}
