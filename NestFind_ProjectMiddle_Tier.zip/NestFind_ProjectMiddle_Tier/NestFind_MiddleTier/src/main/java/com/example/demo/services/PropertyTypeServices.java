package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.City;
import com.example.demo.entities.Property_Type;
import com.example.demo.repositories.PropertyTypeRepository;

@Service
public class PropertyTypeServices {

	@Autowired
	PropertyTypeRepository ptrepo;
	
	
	public List<Property_Type>getAllPropertyType(){
		return ptrepo.findAll();
	}
	
	
	public Property_Type getById(int property_id) {
		return ptrepo.findById(property_id).get();
	}
	
	public Property_Type saveproperty_type(Property_Type property_type) {
		return ptrepo.save(property_type);
	}
	
}
