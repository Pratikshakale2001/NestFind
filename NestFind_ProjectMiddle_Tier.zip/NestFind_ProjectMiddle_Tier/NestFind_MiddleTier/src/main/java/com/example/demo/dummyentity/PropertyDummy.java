package com.example.demo.dummyentity;

import java.util.List;

public class PropertyDummy {

	int property_type_id;
	int user_id;
	double rent_price;
	double deposit;
	String address;
	int state_id;
	int city_id;
	int area_id;
	// int property_amenities_id;
	private List<Integer> amenities_id;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getState_id() {
		return state_id;
	}

	public void setState_id(int state_id) {
		this.state_id = state_id;
	}

	public int getCity_id() {
		return city_id;
	}

	public void setCity_id(int city_id) {
		this.city_id = city_id;
	}

	public int getArea_id() {
		return area_id;
	}

	public void setArea_id(int area_id) {
		this.area_id = area_id;
	}

	public PropertyDummy() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getProperty_type_id() {
		return property_type_id;
	}

	public void setProperty_type_id(int property_type_id) {
		this.property_type_id = property_type_id;
	}

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public double getRent_price() {
		return rent_price;
	}

	public void setRent_price(double rent_price) {
		this.rent_price = rent_price;
	}

	public double getDeposit() {
		return deposit;
	}

	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}

	/*
	 * public int getProperty_amenities_id() { return property_amenities_id; }
	 * 
	 * 
	 * 
	 * public void setProperty_amenities_id(int property_amenities_id) {
	 * this.property_amenities_id = property_amenities_id; }
	 */

	public List<Integer> getAmenities_ids() {
		return amenities_id;
	}

	public void setAmenities_ids(List<Integer> amenities_id) {
		this.amenities_id = amenities_id;
	}

	@Override
	public String toString() {
		return "PropertyDummy [property_type_id=" + property_type_id + ", user_id=" + user_id + ", rent_price="
				+ rent_price + ", deposit=" + deposit + ", address=" + address + ", state_id=" + state_id + ", city_id="
				+ city_id + ", area_id=" + area_id + "]";
	}

}