package com.example.demo.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Amenities;
import com.example.demo.entities.Property_Amenities;
import com.example.demo.repositories.AmenitiesRepository;
import com.example.demo.repositories.PropertyAmenitiesRepository;

@Service
public class PropertyAmenitiesServices {
			
		
		@Autowired
		PropertyAmenitiesRepository parepo;
		
		public List<Property_Amenities>getAllPropAmenities(){
			return parepo.findAll();
		}
		
		
		 public Property_Amenities getPropertyAmenitiesById(int id) {
		        Optional<Property_Amenities> propertyAmenities = parepo.findById(id);
		        return propertyAmenities.orElse(null);
		    }
		 
		 

		public Property_Amenities savePropAmenities(Property_Amenities Property_amenities) {
			return parepo.save(Property_amenities);
		}
		
		 
		
		public void deletePropertyAmenities(int id) {
			parepo.deleteById(id);
	    }


		  public Property_Amenities getByPropertyId(int propertyId) {
		        // Assuming the repository has a method to find by property ID
		        return parepo.findByPropertyId(propertyId);
		    }
}
