package com.example.demo.controllers;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dummyentity.PropertyAmenitiesDummy;
import com.example.demo.entities.Amenities;
import com.example.demo.entities.City;
import com.example.demo.entities.Property;
import com.example.demo.entities.Property_Amenities;
import com.example.demo.services.AmenitiesServices;
import com.example.demo.services.PropertyAmenitiesServices;

@RestController
@RequestMapping("/api/property_amenities")
public class PropertyAmenitiesController {
	
	@Autowired
	PropertyAmenitiesServices paservice;
	
	@Autowired
	AmenitiesServices aservice;
	
	@GetMapping
	public List<Property_Amenities> getAll(){
		return paservice.getAllPropAmenities();
	}
	
	/*@PostMapping
	public Property_Amenities savePropA(@RequestBody Property_Amenities pa) {
		return paservice.savePropAmenities(pa);
	}*/
	
	
	
	
	 @GetMapping("/properties/{propertyId}")
	    public Property_Amenities getAmenitiesByPropertyId(@PathVariable int propertyId) {
	        return paservice.getByPropertyId(propertyId);
	    }
	 
	 
	 
	
	@PostMapping
    public Property_Amenities savePropAmenities(@RequestBody PropertyAmenitiesDummy paDummy) {
        // Fetch the property by ID
        Property property = new Property();
        property.setProperty_id(paDummy.getProperty_id());

        // Fetch amenities by IDs
        Set<Amenities> amenitiesSet = paDummy.getAmenities_ids().stream()
            .map(id -> aservice.getById(id))
            .filter(amenity -> amenity != null) // Filter out null values
            .collect(Collectors.toSet());

        // Create Property_Amenities and set its properties
        Property_Amenities propertyAmenities = new Property_Amenities();
        propertyAmenities.setProperty(property);
        propertyAmenities.setAmenities(amenitiesSet);

        // Save and return the property amenities
        return paservice.savePropAmenities(propertyAmenities);
    }
    }
	
	
	
	
	


