/*package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dummyentity.AreaDummy;
import com.example.demo.dummyentity.LocationDummy;
import com.example.demo.entities.Area;
import com.example.demo.entities.City;
import com.example.demo.entities.Location;
import com.example.demo.entities.Property;
import com.example.demo.services.AreaServices;
import com.example.demo.services.LocationServices;
import com.example.demo.services.PropertyServices;

@RestController
@RequestMapping("/api/lacation")
public class LocationController {

	@Autowired
	LocationServices locservice;
	
	@Autowired
	PropertyServices propservices;
	
	@Autowired
	AreaServices areaservices;
	
	@GetMapping
	public List<Location>getAll(){
		return locservice.getAllLocation();
	}
	
	@PostMapping
	public Location saveloc(@RequestBody LocationDummy ld) {
		int propertyId = ld.getProperty_id();
		Property property = propservices.getById(propertyId);
		int areaId = ld.getArea_id();
		Area area = areaservices.getById(areaId);
	
		
		
		Location location = new Location();
		location.setAddress(ld.getAddress());
		location.setArea(area);
		location.setProperty(property);
	
		
		return locservice.saveloc(location);
		
	}
	
	
}*/
package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dummyentity.AreaDummy;
import com.example.demo.dummyentity.LocationDummy;
import com.example.demo.entities.Area;
import com.example.demo.entities.City;
import com.example.demo.entities.Location;
import com.example.demo.entities.Property;
import com.example.demo.services.AreaServices;
import com.example.demo.services.LocationServices;
import com.example.demo.services.PropertyServices;

@RestController
@RequestMapping("/api/location")
public class LocationController {

	@Autowired
	LocationServices locservice;
	
	@Autowired
	PropertyServices propservices;
	
	@Autowired
	AreaServices areaservices;
	
	@GetMapping
	public List<Location>getAll(){
		return locservice.getAllLocation();
	}
	
	@PostMapping
	public Location saveloc(@RequestBody LocationDummy ld) {
		int propertyId = ld.getProperty_id();
		Property property = propservices.getById(propertyId);
		int areaId = ld.getArea_id();
		Area area = areaservices.getById(areaId);
	
		
		
		Location location = new Location();
		location.setArea(area);
		location.setProperty(property);
	
		
		return locservice.saveloc(location);
		
	}
	
	
}

