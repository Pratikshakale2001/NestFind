package com.example.demo.dummyentity;

public class SearchPropertyDummy {
	
	
	int search_property;
	int location_id;
	int property_id;
	
	
	
	
	
	
	
	

}
