package com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.entities.Property_Amenities;

@Repository

public interface PropertyAmenitiesRepository extends JpaRepository<Property_Amenities, Integer> {
	
	 @Query("SELECT pa FROM Property_Amenities pa WHERE pa.property.property_id = :propertyId")
	    Property_Amenities findByPropertyId(@Param("propertyId") int propertyId);

}
