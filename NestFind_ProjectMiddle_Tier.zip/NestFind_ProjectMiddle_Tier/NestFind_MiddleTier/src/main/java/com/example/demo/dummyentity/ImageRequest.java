package com.example.demo.dummyentity;


public class ImageRequest {
    private String base64Image;

    // Getters and Setters
    public String getBase64Image() {
        return base64Image;
    }

    public void setBase64Image(String base64Image) {
        this.base64Image = base64Image;
    }
}
