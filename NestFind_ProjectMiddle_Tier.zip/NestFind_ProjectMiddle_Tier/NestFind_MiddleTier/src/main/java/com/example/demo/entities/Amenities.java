package com.example.demo.entities;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="amenities")
public class Amenities {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int amenities_id;
	
	String amenities_name;
	
	//aminities and property amenities(m-m)
	// @JsonIgnoreProperties("amenities")
	/*
	 * @ManyToMany(mappedBy = "amenities")
	 * 
	 * @JsonBackReference Set<Property_Amenities> property_amenities;
	 */
	
	//@JsonIgnoreProperties("amenities")
	@ManyToMany(cascade = CascadeType.ALL)
	   @JsonBackReference
	   @JoinTable(
		name = "property_amenities_amenities",
	    joinColumns = @JoinColumn(name = "amenities_id"),
	    inverseJoinColumns = @JoinColumn(name = "property_amenities_id ")
	    )
	    Set<Property_Amenities> property_amenities;
	
	
	public Amenities() {
		super();
		// TODO Auto-generated constructor stub
	}


	
	public Amenities(String amenities_name, Set<Property_Amenities> property_amenities) {
		super();
		this.amenities_name = amenities_name;
		this.property_amenities = property_amenities;
	}


	
	


	public Amenities(String amenities_name) {
		super();
		this.amenities_name = amenities_name;
	}


	
	

	public Amenities(int amenities_id) {
		super();
		this.amenities_id = amenities_id;
	}



	public int getAmenities_id() {
		return amenities_id;
	}

	public void setAmenities_id(int amenities_id) {
		this.amenities_id = amenities_id;
	}

	public String getAmenities_name() {
		return amenities_name;
	}

	public void setAmenities_name(String amenities_name) {
		this.amenities_name = amenities_name;
	}


	public Set<Property_Amenities> getProperty_amenities() {
		return property_amenities;
	}


	public void setProperty_amenities(Set<Property_Amenities> property_amenities) {
		this.property_amenities = property_amenities;
	}
	
	
	
	
	

}
