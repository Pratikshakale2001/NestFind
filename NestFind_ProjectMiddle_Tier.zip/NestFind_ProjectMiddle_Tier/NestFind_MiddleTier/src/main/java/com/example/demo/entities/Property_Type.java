package com.example.demo.entities;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="property_type")
public class Property_Type {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int property_type_id;
	String property_type_name;
	
	
	/* @OneToMany(mappedBy="property_type", cascade= CascadeType.ALL)
	 @JsonBackReference
	 Set<Property>property;*/
 
	 
	public Property_Type() {
		super();
		// TODO Auto-generated constructor stub
	}

	




	public Property_Type(String property_type_name) {
		super();
		this.property_type_name = property_type_name;
		
	}






	public int getProperty_type_id() {
		return property_type_id;
	}

	public void setProperty_type_id(int property_type_id) {
		this.property_type_id = property_type_id;
	}

	public String getProperty_type_name() {
		return property_type_name;
	}

	public void setProperty_type_name(String property_type_name) {
		this.property_type_name = property_type_name;
	}


	

}
