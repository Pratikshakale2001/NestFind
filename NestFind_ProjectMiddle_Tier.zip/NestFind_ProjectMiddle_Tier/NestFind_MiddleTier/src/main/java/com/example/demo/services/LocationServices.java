package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entities.Location;
import com.example.demo.repositories.LocationRepository;

@Service
public class LocationServices {

	
	@Autowired
	LocationRepository locrepo;
	
	public List<Location>getAllLocation(){
		return locrepo.findAll();
	}
	
	public Location saveloc(Location loc) {
		return locrepo.save(loc);
	}
	
	
	 
}
