package com.example.demo.dummyentity;

import java.util.Date;

public class BookingDummy {
	
	  Date b_date;
	    Date start_date;
	    Date end_date;
	    double rent_price;
	    double deposit;
	    int property_id;
	    int user_id;
	    int pay_id;
		public Date getB_date() {
			return b_date;
		}
		public void setB_date(Date b_date) {
			this.b_date = b_date;
		}
		public Date getStart_date() {
			return start_date;
		}
		public void setStart_date(Date start_date) {
			this.start_date = start_date;
		}
		public Date getEnd_date() {
			return end_date;
		}
		public void setEnd_date(Date end_date) {
			this.end_date = end_date;
		}
		public double getRent_price() {
			return rent_price;
		}
		public void setRent_price(double rent_price) {
			this.rent_price = rent_price;
		}
		public double getDeposit() {
			return deposit;
		}
		public void setDeposit(double deposit) {
			this.deposit = deposit;
		}
		public int getProperty_id() {
			return property_id;
		}
		public void setProperty_id(int property_id) {
			this.property_id = property_id;
		}
		public int getUser_id() {
			return user_id;
		}
		public void setUser_id(int user_id) {
			this.user_id = user_id;
		}
		public int getPay_id() {
			return pay_id;
		}
		public void setPay_id(int pay_id) {
			this.pay_id = pay_id;
		}
	    
	    
	    

}
