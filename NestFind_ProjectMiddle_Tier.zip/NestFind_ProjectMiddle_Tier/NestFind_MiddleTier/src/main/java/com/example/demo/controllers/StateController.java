package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dummyentity.CityDummy;
import com.example.demo.dummyentity.StateDummy;
import com.example.demo.entities.City;
import com.example.demo.entities.State;
import com.example.demo.services.StateServices;


@RestController
@RequestMapping("/api/states")
public class StateController {


	@Autowired
	StateServices stateservice;
	
	@GetMapping
	public List<State>getAll(){
		return stateservice.getAllState();
	}
	
	
	
	
	
	@PostMapping
    public State saveState(@RequestBody StateDummy sd) {
       

        State state = new State();
        state.setState_id(sd.getState_id());
        state.setState_name(sd.getState_name());
       
        return stateservice.saveState(state);
    }
	
	 @GetMapping("/{id}")
	    public ResponseEntity<State> getById(@PathVariable int id) {
	        State state = stateservice.getById(id);
	        if (state != null) {
	            return ResponseEntity.ok(state);
	        }
	        return ResponseEntity.notFound().build();
	    }
	

	 @PutMapping("/{id}")
	    public ResponseEntity<State> updateState(@PathVariable int id, @RequestBody State stateDetails) {
	        State updatedState = stateservice.updateState(id, stateDetails);
	        if (updatedState != null) {
	            return ResponseEntity.ok(updatedState);
	        }
	        return ResponseEntity.notFound().build();
	    }

	    
	    // Delete a state by ID
	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> deleteState(@PathVariable int id) {
	        boolean isDeleted = stateservice.deleteState(id);
	        if (isDeleted) {
	            return ResponseEntity.noContent().build();
	        }
	        return ResponseEntity.notFound().build();
	    }
	 
	 
	
}
