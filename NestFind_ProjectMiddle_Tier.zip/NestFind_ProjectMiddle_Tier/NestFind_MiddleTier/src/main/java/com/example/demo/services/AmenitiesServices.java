package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Amenities;
import com.example.demo.entities.Area;
import com.example.demo.repositories.AmenitiesRepository;


@Service
public class AmenitiesServices {
	
	
	@Autowired
	AmenitiesRepository arepo;
	
	public List<Amenities>getAllAmenities(){
		return arepo.findAll();
	}

	public Amenities saveamenities(Amenities amenities) {
		return arepo.save(amenities);
	}
	
	 public Amenities getById(int amenitiesId) {
	        return arepo.findById(amenitiesId).orElse(null);
	    }
}
