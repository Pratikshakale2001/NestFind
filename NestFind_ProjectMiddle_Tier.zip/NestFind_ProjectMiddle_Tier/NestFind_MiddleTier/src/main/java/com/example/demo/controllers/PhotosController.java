package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dummyentity.ImageRequest;
import com.example.demo.entities.Photos;
import com.example.demo.services.PhotoService;
import com.example.demo.services.PhotosServices;

@RestController
public class PhotosController {
	
	@Autowired
	PhotoService phservice;//Interface
	
	@Autowired
	PhotosServices pservice;
	
	@GetMapping("/getphotos")
	public List<Photos> getAll(){
		return pservice.getAllPhotos();
	}
	
	
	@PostMapping("/upload")
    public void uploadPhoto(@RequestBody String base64Image) {
        phservice.savePhoto(base64Image);
    }

}
