package com.example.demo.controllers;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Area;
import com.example.demo.entities.City;
import com.example.demo.dummyentity.AreaDummy;
import com.example.demo.services.AreaServices;
import com.example.demo.services.CityServices;


	
	@RestController
	@RequestMapping("/api/areas")
	public class AreaController {
		
		@Autowired
		AreaServices areaservice;
		
		@Autowired
		CityServices cityservice;
		
		@GetMapping
		public List<Area> getAll(){
			return areaservice.getAllAreas();
		}
		
		
		@GetMapping("/{id}")
	    public Area getAreaById(@PathVariable int id) {
	        return areaservice.getById(id);
	    }
		
		
		@PostMapping
		public Area saveArea(@RequestBody AreaDummy ad) {
			int cityId = ad.getCity_id();
			City city = cityservice.getById(cityId);
			
			Area area = new Area();
			area.setArea_name(ad.getArea_name());
			area.setPin_code(ad.getPin_code());
			area.setCity(city);
			
			return areaservice.savearea(area);
			
		}

	}


