package com.example.demo.entities;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="role")
public class Role {
	
	
	@Id
	int role_id;
	
	String role_name;
	
	
	
	//@JsonIgnoreProperties("role")
	@OneToMany(mappedBy="role", cascade= CascadeType.ALL)
	 @JsonManagedReference
	Set<User>users;
	
	
	
	public Role() {
		super();
		// TODO Auto-generated constructor stub
	}




	public Role(String role_name, Set<User> users) {
		super();
		this.role_name = role_name;
		this.users = users;
	}




	public Set<User> getUsers() {
		return users;
	}




	public void setUsers(Set<User> users) {
		this.users = users;
	}




	public int getRole_id() {
		return role_id;
	}


	public void setRole_id(int role_id) {
		this.role_id = role_id;
	}


	public String getRole_name() {
		return role_name;
	}


	public void setRole_name(String role_name) {
		this.role_name = role_name;
	}
	
	
	
	

}
