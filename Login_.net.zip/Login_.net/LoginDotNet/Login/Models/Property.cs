﻿using System;
using System.Collections.Generic;

namespace Login.Models;

public partial class Property
{
    public int PropertyId { get; set; }

    public int? PropertyTypeId { get; set; }

    public int? UserId { get; set; }

    public double? RentPrice { get; set; }

    public double? Deposit { get; set; }

    public virtual ICollection<Booking>? Bookings { get; set; } = new List<Booking>();

    public virtual Location? Location { get; set; }

    public virtual ICollection<Photo>? Photos { get; set; } = new List<Photo>();

    public virtual ICollection<PropertyAmenity>? PropertyAmenities { get; set; } = new List<PropertyAmenity>();

    public virtual PropertyType? PropertyType { get; set; } = null!;

    public virtual User? User { get; set; } = null!;
}
