﻿using System;
using System.Collections.Generic;

namespace Login.Models;

public partial class Amenity
{
    public int AmenitiesId { get; set; }

    public string? AmenitiesName { get; set; }

    public virtual ICollection<PropertyAmenity>? PropertyAmenities { get; set; } = new List<PropertyAmenity>();
}
