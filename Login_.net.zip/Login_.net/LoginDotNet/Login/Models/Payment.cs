﻿using System;
using System.Collections.Generic;

namespace Login.Models;

public partial class Payment
{
    public int PayId { get; set; }

    public string? PayMode { get; set; }

    public DateOnly? PayDate { get; set; }

    public double? Amount { get; set; }

    public virtual ICollection<Booking>? Bookings { get; set; } = new List<Booking>();
}
