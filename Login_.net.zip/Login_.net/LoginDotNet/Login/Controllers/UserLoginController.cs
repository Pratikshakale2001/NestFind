﻿using Login.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Login.Controllers
{
    [Route("api/[controller]/[action]")]
    [EnableCors]
    [ApiController]
    public class UserLoginController : ControllerBase
    {
        [HttpGet]
        public List<User> GetUsers()
        {
            List<User> result = new List<User>();
            using (var db = new NestfindContext())
            {
                result = db.Users.ToList();
            }
            return result;
        }

        //This method will save the data in user table
        [HttpPost]
        public User SaveUser(User user)
        {
            using (var db = new NestfindContext())
            {
                user.Password = BCrypt.Net.BCrypt.HashPassword(user.Password);
                db.Users.Add(user);
                db.SaveChanges();
            }
            return user;
        }

        [HttpPost]
        public IActionResult VerifyUser(User user)
        {
            User? userdb;

            using (var db = new NestfindContext())
            {
                userdb = db.Users.Where(u => u.UserName == user.UserName)
                    .FirstOrDefault();

                if (userdb != null && BCrypt.Net.BCrypt.Verify(user.Password, userdb.Password))
                {
                    //Return an object that includes the roleId

                    var response = new
                    {
                        userdb.UserName,
                        userdb.RoleId,
                        userdb.UserId
                        //Include other properties if necessary
                    };

                    return Ok(response);

                }
                return Unauthorized(new { message = "Invalid username or password." });

            }
        }
    }
}